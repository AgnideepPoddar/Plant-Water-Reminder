import SwiftUI

// 🌿 Plant Model
struct Plant: Identifiable, Codable {
    let id: UUID
    var name: String
    var lastWateredDate: Date
    var wateringInterval: TimeInterval
    var growthStage: Int

    var nextWateringDate: Date {
        lastWateredDate.addingTimeInterval(wateringInterval)
    }
}

// 🌳 Main App
@main
struct PlantWaterReminderApp: App {
    @StateObject private var viewModel = PlantViewModel()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}

// 🌼 Plant ViewModel (Logic Layer)
@MainActor
class PlantViewModel: ObservableObject {
    @Published var plants: [Plant] = []
    
    init() {
        loadPlants()
    }

    // ✅ Add New Plant
    func addPlant(name: String, wateringInterval: TimeInterval) {
        let newPlant = Plant(
            id: UUID(),
            name: name,
            lastWateredDate: Date(),
            wateringInterval: wateringInterval,
            growthStage: 1
        )
        plants.append(newPlant)
        savePlants()
    }

    // 💧 Water a Plant
    func waterPlant(_ plant: Plant) {
        guard let index = plants.firstIndex(where: { $0.id == plant.id }) else { return }
        plants[index].lastWateredDate = Date()
        plants[index].growthStage = min(plants[index].growthStage + 1, 5)
        savePlants()
    }

    // ❌ Delete Plant
    func deletePlant(id: UUID) {
        plants.removeAll { $0.id == id }
        savePlants()
    }

    // 💾 Save Plants to UserDefaults
    private func savePlants() {
        if let encoded = try? JSONEncoder().encode(plants) {
            UserDefaults.standard.set(encoded, forKey: "plants")
        }
    }

    // 🔄 Load Plants from UserDefaults
    private func loadPlants() {
        if let data = UserDefaults.standard.data(forKey: "plants"),
           let decoded = try? JSONDecoder().decode([Plant].self, from: data) {
            plants = decoded
        }
    }
}

// 📱 ContentView: Main Screen
struct ContentView: View {
    @EnvironmentObject var viewModel: PlantViewModel
    @State private var showAddPlantSheet = false
    @State private var isEditing = false
    
    // 🌿 Dynamic Plant Care Tip
    @State private var plantCareTip: String = getPlantCareTip()

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.6), Color.blue.opacity(0.3)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                .ignoresSafeArea()

                VStack {
                    // 🌿 Dynamic Plant Care Tip
                    Text(plantCareTip)
                        .font(.headline)
                        .padding()
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(12)
                        .shadow(radius: 5)
                        .transition(.move(edge: .top))

                    if viewModel.plants.isEmpty {
                        emptyStateView
                    } else {
                        ScrollView {
                            LazyVStack {
                                ForEach(viewModel.plants) { plant in
                                    PlantCard(plant: plant, onWater: {
                                        viewModel.waterPlant(plant)
                                    }, isEditing: $isEditing, onDelete: {
                                        viewModel.deletePlant(id: plant.id)
                                    })
                                }
                            }
                            .padding()
                        }
                    }
                }
            }
            .navigationTitle("Plant Water Reminder")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(isEditing ? "Done" : "Edit") {
                        isEditing.toggle()
                    }
                    .foregroundColor(.green) // ✅ Updated to green
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showAddPlantSheet.toggle()
                    } label: {
                        Image(systemName: "plus")
                            .foregroundColor(.green)
                    }
                }
            }
            .sheet(isPresented: $showAddPlantSheet) {
                AddPlantView(isPresented: $showAddPlantSheet)
            }
            .onAppear {
                plantCareTip = getPlantCareTip()
            }
        }
    }

    // 🌱 Empty State View
    private var emptyStateView: some View {
        VStack {
            Image(systemName: "leaf.arrow.circlepath")
                .resizable()
                .scaledToFit()
                .frame(width: 120, height: 120)
                .foregroundColor(.green)

            Text("No plants yet!")
                .font(.title2)
                .foregroundColor(.gray)

            Button(action: {
                showAddPlantSheet.toggle()
            }) {
                Text("Add Your First Plant")
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
    }
}

// 🌼 Add Plant View
struct AddPlantView: View {
    @EnvironmentObject var viewModel: PlantViewModel
    @Binding var isPresented: Bool
    @State private var plantName = ""
    @State private var wateringInterval: TimeInterval = 86400
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Plant Details")) {
                    TextField("Plant Name", text: $plantName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    Picker("Watering Interval", selection: $wateringInterval) {
                        Text("Every 12 Hours").tag(43200.0)
                        Text("Every 24 Hours").tag(86400.0)
                        Text("Every 2 Days").tag(172800.0)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }

                Button("Save Plant") {
                    if !plantName.isEmpty {
                        viewModel.addPlant(name: plantName, wateringInterval: wateringInterval)
                        isPresented = false
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(8)
            }
            .navigationTitle("Add Plant")
            .toolbar {
                Button("Cancel") {
                    isPresented = false
                }
            }
        }
    }
}

// 🌳 Plant Card View
struct PlantCard: View {
    let plant: Plant
    let onWater: () -> Void
    @Binding var isEditing: Bool
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(plant.name)
                    .font(.title2)
                    .bold()
                
                Text("Next Watering: \(plant.nextWateringDate, style: .date)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            Spacer()

            if isEditing {
                Button(action: onDelete) {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                        .padding()
                        .background(Color.white)
                        .clipShape(Circle())
                        .shadow(radius: 5)
                }
            } else {
                Button(action: onWater) {
                    Image(systemName: "drop.fill")
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color.white)
                        .clipShape(Circle())
                        .shadow(radius: 5)
                }
            }
        }
        .padding()
        .background(Color.green.opacity(0.2))
        .cornerRadius(12)
        .shadow(radius: 3)
        .padding(.horizontal)
    }
}

// 🌿 Get Dynamic Plant Care Tip
func getPlantCareTip() -> String {
    let hour = Calendar.current.component(.hour, from: Date())
    
    switch hour {
    case 6..<12: return "☀️ Morning: A great time to water your plants!"
    case 12..<17: return "🌞 Afternoon: Keep plants in shade if it's too hot."
    case 17..<21: return "🌆 Evening: Mist plants & check for pests."
    default: return "🌙 Night: Let your plants rest!"
    }
}
